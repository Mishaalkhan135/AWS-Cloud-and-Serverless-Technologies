import { APIGatewayProxyEvent, APIGatewayProxyResult, Context } from "aws-lambda";
declare const handler: (event: APIGatewayProxyEvent, context: Context) => Promise<APIGatewayProxyResult>;
export default handler;
