"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const handler = async (event, context) => {
    console.log("request:", event);
    return {
        statusCode: 200,
        headers: { "Content-Type": "text/plain" },
        body: `Hello, Mishaal khan The Cloud Architect!. You've hit ${event.path}\n`,
    };
};
exports.default = handler;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibXlOZXdMYW1iZGEuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJteU5ld0xhbWJkYS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQU1BLE1BQU0sT0FBTyxHQUFDLEtBQUssRUFBQyxLQUEyQixFQUFDLE9BQWdCLEVBQWlDLEVBQUU7SUFDakcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDL0IsT0FBTztRQUNMLFVBQVUsRUFBRSxHQUFHO1FBQ2YsT0FBTyxFQUFFLEVBQUUsY0FBYyxFQUFFLFlBQVksRUFBRTtRQUN6QyxJQUFJLEVBQUUsd0RBQXdELEtBQUssQ0FBQyxJQUFJLElBQUk7S0FDN0UsQ0FBQztBQUNKLENBQUMsQ0FBQTtBQUNELGtCQUFlLE9BQU8sQ0FBQSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBBUElHYXRld2F5UHJveHlFdmVudCxcclxuICAgIEFQSUdhdGV3YXlQcm94eVJlc3VsdCxcclxuICAgIENvbnRleHQsXHJcbiAgfSBmcm9tIFwiYXdzLWxhbWJkYVwiO1xyXG4gIFxyXG5jb25zdCBoYW5kbGVyPWFzeW5jKGV2ZW50OiBBUElHYXRld2F5UHJveHlFdmVudCxjb250ZXh0OiBDb250ZXh0KTogUHJvbWlzZTxBUElHYXRld2F5UHJveHlSZXN1bHQ+PT4ge1xyXG4gIGNvbnNvbGUubG9nKFwicmVxdWVzdDpcIiwgZXZlbnQpO1xyXG4gIHJldHVybiB7XHJcbiAgICBzdGF0dXNDb2RlOiAyMDAsXHJcbiAgICBoZWFkZXJzOiB7IFwiQ29udGVudC1UeXBlXCI6IFwidGV4dC9wbGFpblwiIH0sXHJcbiAgICBib2R5OiBgSGVsbG8sIE1pc2hhYWwga2hhbiBUaGUgQ2xvdWQgQXJjaGl0ZWN0IS4gWW91J3ZlIGhpdCAke2V2ZW50LnBhdGh9XFxuYCxcclxuICB9O1xyXG59XHJcbmV4cG9ydCBkZWZhdWx0IGhhbmRsZXIiXX0=