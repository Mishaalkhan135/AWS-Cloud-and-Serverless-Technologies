"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
async function handler(event, context) {
    console.log("request:", event);
    return {
        statusCode: 200,
        headers: { "Content-Type": "text/plain" },
        body: `Hello, Mishaal khan The Cloud Architect!. You've hit ${event.path}\n`,
    };
}
exports.handler = handler;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibXlOZXdMYW1iZGEuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJteU5ld0xhbWJkYS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFNTyxLQUFLLFVBQVUsT0FBTyxDQUFDLEtBQTJCLEVBQUMsT0FBZ0I7SUFDeEUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDL0IsT0FBTztRQUNMLFVBQVUsRUFBRSxHQUFHO1FBQ2YsT0FBTyxFQUFFLEVBQUUsY0FBYyxFQUFFLFlBQVksRUFBRTtRQUN6QyxJQUFJLEVBQUUsd0RBQXdELEtBQUssQ0FBQyxJQUFJLElBQUk7S0FDN0UsQ0FBQztBQUNKLENBQUM7QUFQRCwwQkFPQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBBUElHYXRld2F5UHJveHlFdmVudCxcclxuICAgIEFQSUdhdGV3YXlQcm94eVJlc3VsdCxcclxuICAgIENvbnRleHQsXHJcbiAgfSBmcm9tIFwiYXdzLWxhbWJkYVwiO1xyXG4gIFxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaGFuZGxlcihldmVudDogQVBJR2F0ZXdheVByb3h5RXZlbnQsY29udGV4dDogQ29udGV4dCk6IFByb21pc2U8QVBJR2F0ZXdheVByb3h5UmVzdWx0PiB7XHJcbiAgY29uc29sZS5sb2coXCJyZXF1ZXN0OlwiLCBldmVudCk7XHJcbiAgcmV0dXJuIHtcclxuICAgIHN0YXR1c0NvZGU6IDIwMCxcclxuICAgIGhlYWRlcnM6IHsgXCJDb250ZW50LVR5cGVcIjogXCJ0ZXh0L3BsYWluXCIgfSxcclxuICAgIGJvZHk6IGBIZWxsbywgTWlzaGFhbCBraGFuIFRoZSBDbG91ZCBBcmNoaXRlY3QhLiBZb3UndmUgaGl0ICR7ZXZlbnQucGF0aH1cXG5gLFxyXG4gIH07XHJcbn0iXX0=