"use strict";
exports.handler = async (event) => {
    if (event.info.fieldName === "welcome") {
        return "Welcome from appsync lambda";
    }
    else if (event.info.fieldName === "hello") {
        return "Hello from appsync lambda";
    }
    else if (event.info.fieldName === "addProduct") {
        console.log("Event data here", event.arguments.product);
        return event.arguments.product;
        // return "Product Data " + event.arguments.product.name
    }
    else {
        return "Not Found";
    }
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoid2VsY29tZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIndlbGNvbWUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQWNBLE9BQU8sQ0FBQyxPQUFPLEdBQUcsS0FBSyxFQUFFLEtBQWtCLEVBQUUsRUFBRTtJQUMzQyxJQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxLQUFLLFNBQVMsRUFBQztRQUNsQyxPQUFPLDZCQUE2QixDQUFBO0tBQ3ZDO1NBQ0ksSUFBRyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsS0FBSyxPQUFPLEVBQ3hDO1FBQ0ksT0FBTywyQkFBMkIsQ0FBQTtLQUNyQztTQUNJLElBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLEtBQUssWUFBWSxFQUFDO1FBQzFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLEVBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN2RCxPQUFPLEtBQUssQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFBO1FBQy9CLHdEQUF3RDtLQUMxRDtTQUNHO1FBQ0EsT0FBTyxXQUFXLENBQUE7S0FDckI7QUFDTCxDQUFDLENBQUEiLCJzb3VyY2VzQ29udGVudCI6WyJcclxudHlwZSBBcHBTeW5jRXZlbnQ9IHtcclxuICAgIGluZm86e1xyXG4gICAgICAgIGZpZWxkTmFtZTpTdHJpbmdcclxuICAgIH1cclxuICAgIGFyZ3VtZW50czp7XHJcbiAgICAgICAgcHJvZHVjdDpQcm9kdWN0XHJcbiAgICB9XHJcbn1cclxudHlwZSBQcm9kdWN0ID17XHJcbiAgICBuYW1lOlN0cmluZ1xyXG4gICAgcHJpY2U6TnVtYmVyXHJcbn1cclxuXHJcbmV4cG9ydHMuaGFuZGxlciA9IGFzeW5jIChldmVudDpBcHBTeW5jRXZlbnQpID0+IHtcclxuICAgIGlmKGV2ZW50LmluZm8uZmllbGROYW1lID09PSBcIndlbGNvbWVcIil7XHJcbiAgICAgICAgcmV0dXJuIFwiV2VsY29tZSBmcm9tIGFwcHN5bmMgbGFtYmRhXCJcclxuICAgIH1cclxuICAgIGVsc2UgaWYoZXZlbnQuaW5mby5maWVsZE5hbWUgPT09IFwiaGVsbG9cIilcclxuICAgIHtcclxuICAgICAgICByZXR1cm4gXCJIZWxsbyBmcm9tIGFwcHN5bmMgbGFtYmRhXCJcclxuICAgIH1cclxuICAgIGVsc2UgaWYoZXZlbnQuaW5mby5maWVsZE5hbWUgPT09IFwiYWRkUHJvZHVjdFwiKXtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIkV2ZW50IGRhdGEgaGVyZVwiLGV2ZW50LmFyZ3VtZW50cy5wcm9kdWN0KTtcclxuICAgICAgICByZXR1cm4gZXZlbnQuYXJndW1lbnRzLnByb2R1Y3RcclxuICAgICAgIC8vIHJldHVybiBcIlByb2R1Y3QgRGF0YSBcIiArIGV2ZW50LmFyZ3VtZW50cy5wcm9kdWN0Lm5hbWVcclxuICAgIH1cclxuICAgIGVsc2V7XHJcbiAgICAgICAgcmV0dXJuIFwiTm90IEZvdW5kXCJcclxuICAgIH1cclxufSJdfQ==