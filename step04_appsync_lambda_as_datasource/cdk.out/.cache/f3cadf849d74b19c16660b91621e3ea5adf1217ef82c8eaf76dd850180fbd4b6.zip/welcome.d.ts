declare type AppSyncEvent = {
    info: {
        fieldName: String;
    };
    arguments: {
        product: Product;
    };
};
declare type Product = {
    name: String;
    price: Number;
};
